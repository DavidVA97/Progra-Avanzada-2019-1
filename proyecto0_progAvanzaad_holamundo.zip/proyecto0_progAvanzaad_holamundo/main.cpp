#include <cstdlib>
#include <iostream>

using namespace std; /*cin, cout, endl*/

#define ARCHIVO TXT c:/Users/Sala5/archivo.txt //respaldo de datos

int main(int argc, char *argv[])
{
    cout<<"HOLA MUNDO C++ curso: Programaci\'on avanzada"<<endl;
    system("PAUSE>NULL");
    return EXIT_SUCCESS;
}
